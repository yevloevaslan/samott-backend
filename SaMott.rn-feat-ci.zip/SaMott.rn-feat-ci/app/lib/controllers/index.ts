import UserController from "./UserController";

export { UserController };

import React from "react";
import { StyleSheet, View } from "react-native";

const styles = StyleSheet.create({
  container: {},
});

interface Props {}

const PhotoMission = (props: Props) => {
  const {} = props;
  return <View style={styles.container} />;
};

export default PhotoMission;

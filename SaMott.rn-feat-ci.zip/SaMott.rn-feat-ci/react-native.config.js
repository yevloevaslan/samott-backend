module.exports = {
  project: { ios: {}, android: {} },
  assets: ["./app/assets/fonts/Roboto/"],
  plugins: [["@babel/plugin-proposal-class-properties", { loose: true }]],
};
